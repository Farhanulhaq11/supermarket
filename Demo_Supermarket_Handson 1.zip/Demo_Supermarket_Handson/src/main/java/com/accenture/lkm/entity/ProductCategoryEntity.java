package com.accenture.lkm.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The ProductCategoryEntity class represents the "productcategory" table in the database.
 * It contains details about the product category such as category id and category name.
 */
@Entity
@Table(name = "productcategory")
public class ProductCategoryEntity {
    
    @Id
    private Integer categoryId;
    private String categoryName;
    
    /**
     * Gets the Category ID of the Product Category.
     *
     * @return categoryId
     */
    public Integer getCategoryId() {
        return categoryId;
    }

    /**
     * Sets the Category ID of the Product Category.
     *
     * @param categoryId 
     */
    public void setCatgeoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    /**
     * Gets the Category Name of the Product Category.
     *
     * @return categoryName 
     */
    public String getCategoryName() {
        return categoryName;
    }

    /**
     * Sets the Category Name of the Product Category
     *
     * @param categoryName 
     */
    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
}
