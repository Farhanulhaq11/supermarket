package com.accenture.lkm.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accenture.lkm.businessbeans.ProductCategoryBean;
import com.accenture.lkm.businessbeans.DateRangeBean;
import com.accenture.lkm.businessbeans.ProductBean;
import com.accenture.lkm.dao.ProductDAOWrapper;
import com.accenture.lkm.exception.ProductStoreException;

/**
 * Service implementation for Product CRUD operations.
 */
@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    ProductDAOWrapper productDAOWrapper;

    /**
     * Add products.
     * @param productBean the details of the product
     * @return the product id of newly added product
     * @throws ProductStoreException if the user has already added 3 products of same category
     */
    @Override
    public Integer addProduct(ProductBean productBean) throws ProductStoreException {
        return productDAOWrapper.addProduct(productBean);
    }

    /**
     * Retrieves all products between expiry date range.
     * @param dateRangeBean the date range for filtering products
     * @return a list of ProductBean objects
     * @throws Exception if an error occurs
     */
    @Override
    public List<ProductBean> showAllProductsBetweenExpiryDates(DateRangeBean dateRangeBean) throws Exception {
        return productDAOWrapper.showAllProductsBetweenExpiryDates(dateRangeBean);
    }

    /**
     * Retrieves all products based on category.
     * @param productBean contains the product category
     * @return a list of ProductBean objects
     * @throws Exception if an error occurs
     */
    @Override
    public List<ProductBean> showAllProductsByCategory(ProductBean productBean) throws Exception {
        return productDAOWrapper.showAllProductsByCategory(productBean);
    }

    /**
     * Retrieves all product details between price range and sorted in descending by manufacture date
     * @param lowerBound lower price range
     * @param upperBound upper price range
     * @return the list of ProductBean objects
     * @throws Exception if an error occurs 
     */
    @Override
    public List<ProductBean> getAllProductsBetweenPriceAndSortedByManufactureDate(Double lowerBound,Double upperBound) throws Exception{
        return productDAOWrapper.getAllProductsBetweenPriceAndSortedByManufactureDate(lowerBound, upperBound);
    }

  
    /**
     * Retrieves list of product categories.
     * @return a list of String objects of product categories
     */
    @Override
    public List<String> getAllProductCategory()throws Exception{
    	List<String> productCategoryList=new ArrayList<>();
        List<ProductCategoryBean> productCategoryBeanList= productDAOWrapper.getAllProductCategory();
        productCategoryBeanList.forEach(productBean->{
        	String category=productBean.getCategoryName();
        	productCategoryList.add(category);
        });
        return productCategoryList;
    }
}
