package com.accenture.lkm.service;


import java.util.List;
import java.util.Map;

import com.accenture.lkm.businessbeans.DateRangeBean;
import com.accenture.lkm.businessbeans.ProductBean;
import com.accenture.lkm.exception.ProductStoreException;

public interface ProductService {
	public Integer addProduct(ProductBean productBean) throws ProductStoreException;
	public List<ProductBean> showAllProductsBetweenExpiryDates(DateRangeBean dateRangeBean) throws Exception;
	public List<ProductBean> showAllProductsByCategory(ProductBean productBean) throws Exception;
	public List<ProductBean> getAllProductsBetweenPriceAndSortedByManufactureDate(Double lowerBound,Double upperBound) throws Exception;
	public List<String> getAllProductCategory()throws Exception;
}
