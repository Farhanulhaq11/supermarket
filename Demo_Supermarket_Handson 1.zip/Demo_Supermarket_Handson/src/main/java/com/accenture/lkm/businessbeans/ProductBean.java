package com.accenture.lkm.businessbeans;

import java.util.Date;

import javax.validation.constraints.Future;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * The ProductBean class represents a Product with attributes such as productId, productName, categoryName, price, quantityInStock, expiryDate,manufactureDate.
 * It includes getter and setter methods for each attribute and two constructors for creating ProductBean instances
 *  and validation annotations for validating the fields.
 */
public class ProductBean {
    
    //productId
    private Integer productId;
    
    //productName
    @NotBlank
    private String productName;
    
    //categoryName
    @NotNull
    private String categoryName;
  
    // price
    @NotNull
    @Min(10)
    private Double price;
    
    // quantityInStock
    @NotNull
    @Min(1)
    private Integer quantityInStock;
    
    //expiryDate
    @Future
    @DateTimeFormat(pattern="dd-MMM-yyyy")
    private Date expiryDate;
    
    //manufactureDate
    @Past
    @DateTimeFormat(pattern="dd-MMM-yyyy")
    private Date manufactureDate;
    
    // no-args constructor
    public ProductBean() {
    }
    
    //Constructor with productId, productName, price and quantityInStock parameters
    public ProductBean(Integer productId, String productName,String categoryName, double price, int quantityInStock, Date expiryDate,
			Date manufactureDate) {
		this.productId = productId;
		this.productName = productName;
		this.categoryName=categoryName;
		this.price = price;
		this.quantityInStock = quantityInStock;
		this.expiryDate = expiryDate;
		this.manufactureDate = manufactureDate;
	}
    
    //Constructor with categoryName parameters
    public ProductBean(String categoryName) {
		this.categoryName=categoryName;
	}
    
	//Getter productId
	public Integer getProductId() {
		return productId;
	}
	
	//Setter productId
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	
	//Getter productName
	public String getProductName() {
		return productName;
	}
	
	//Setter productName
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	//Getter price
	public Double getPrice() {
		return price;
	}
	//Getter categoryName
	public String getCategoryName() {
		return categoryName;
	}
	//Setter categoryName
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	//Setter price
	public void setPrice(Double price) {
		this.price = price;
	}
	
	//Getter quantityInStock 
	public Integer getQuantityInStock() {
		return quantityInStock;
	}
	
	//Setter quantityInStock 
	public void setQuantityInStock(Integer quantityInStock) {
		this.quantityInStock = quantityInStock;
	}
	//Getter expiryDate
	public Date getExpiryDate() {
		return expiryDate;
	}
	//Setter expiryDate
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	//Getter manufactureDate
	public Date getManufactureDate() {
		return manufactureDate;
	}
	//Setter manufactureDate
	public void setManufactureDate(Date manufactureDate) {
		this.manufactureDate = manufactureDate;
	}
}
