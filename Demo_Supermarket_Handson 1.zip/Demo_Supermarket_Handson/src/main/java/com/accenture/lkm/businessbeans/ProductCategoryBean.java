package com.accenture.lkm.businessbeans;

import java.util.Date;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * The ProductCategoryBean class represents the Product Category for product categorization. It includes attributes such as
 * category id and category name
 * It also includes getter and setter methods for each attribute, constructors for creating instances, 
 *
 */
public class ProductCategoryBean {
    
    //categoryId
    private Integer categoryId;
    
    //categoryName
    private String categoryName;
    
    // no-args constructor
    public ProductCategoryBean() {
    }
    
    // Constructor with categoryId parameter
    public ProductCategoryBean(Integer categoryId) {
        this.categoryId = categoryId;
    }
    // Constructor with categoryId and categoryName parameter
    public ProductCategoryBean(Integer categoryId, String categoryName) {
		super();
		this.categoryId = categoryId;
		this.categoryName = categoryName;
	}
    
    //Getter categoryId
	public Integer getCategoryId() {
		return categoryId;
	}
	//Setter categoryId
	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}
	//Getter categoryName
	public String getCategoryName() {
		return categoryName;
	}
	//Setter categoryName
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
    
}
