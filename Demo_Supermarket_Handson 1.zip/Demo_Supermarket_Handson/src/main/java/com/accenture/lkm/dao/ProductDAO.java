package com.accenture.lkm.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.lkm.entity.ProductEntity;

/**
 * The ProductDAO interface provides methods for performing CRUD operations on ProductEntity object.
 * It uses Spring Data's RepositoryDefinition annotation to define the repository and specifies
 * the transaction management settings. Custom queries are defined using the @Query annotation.
 */
@RepositoryDefinition(idClass = Integer.class, domainClass = ProductEntity.class)
@Transactional(value = "txManager")
public interface ProductDAO {

    /**
     * Saves a given ProductEntity to the database.
     *
     * @param entity the ProductEntity to save
     * @return the saved ProductEntity
     */
    public ProductEntity save(ProductEntity entity);

    /**
     * Retrieves all ProductEntity objects with return dates between the specified dates.
     *
     * @param dateFrom the start date of the range
     * @param dateTo the end date of the range
     * @return a list of ProductEntity objects with return dates between the specified dates
     */
    @Query(name = "findAllProductsBetweenExpiryDates")
    public List<ProductEntity> findAllProductsBetweenExpiryDates(@Param("dateFrom") Date dateFrom, @Param("dateTo") Date dateTo);

    /**
     * Retrieves all ProductEntity objects associated with the specified category.
     *
     * @param category the category associated with the ProductEntity objects to retrieve
     * @return a list of ProductEntity objects associated with the specified category
     */
    @Query(name = "findAllProductsByCategory")
    public List<ProductEntity> findAllProductsByCategory(String category);
    
    
    /**
     * Retrieves all ProductEntity objects between the price range and sort them in descending by manufacture date.
     *
     * @param lowerBound parameter 
     * @param upperBound parameter
     * @return a list of ProductEntity objects between the specified dates sorted descending by manufacture date
     */
    @Query(name = "findAllProductsBetweenPriceAndSortDescending")
    public List<ProductEntity> findAllProductsBetweenPriceAndSortDescending(@Param("lowerBound") Double lowerBound, @Param("upperBound") Double upperBound);

}
