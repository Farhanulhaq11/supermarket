package com.accenture.lkm.test;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.lkm.businessbeans.ProductBean;

import com.accenture.lkm.service.ProductServiceImpl;

/**
 * Unit tests for {@link BookRentServiceImpl}.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/root-config.xml"})
@Transactional
public class ProductServiceImplTest {

    @Autowired
    ProductServiceImpl productServiceImpl;

    /**
     * Test case to verify all product category.
     * @throws Exception 
     */
    @Test
    public void testGetAllCategory() throws Exception {
        // Retrieve all books and assert that the map is not empty
        List<String> categoryList = productServiceImpl.getAllProductCategory();
        assertTrue(categoryList.size() > 0);
    }

    /**
     * Test case to verify fetching products between price range
     * @throws Exception if an error occurs during test execution
     */
    @Test
    public void testShowAllProductsBetweenPriceRange() throws Exception {
        Double minPrice=100.00;
        Double maxPrice=700.00;
        // Retrieve rented books within the date range and assert the result
        List<ProductBean> productList = productServiceImpl.getAllProductsBetweenPriceAndSortedByManufactureDate(minPrice, maxPrice);
        assertTrue(productList.size()>0);
    }
}
