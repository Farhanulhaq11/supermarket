package com.accenture.lkm.test;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;


import com.accenture.lkm.businessbeans.ProductBean;
import com.accenture.lkm.dao.ProductDAOWrapper;

/**
 * Unit tests for {@link BookRentDAOWrapper}.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/root-config.xml" })
@Transactional
public class ProductDAOWrapperTest {

    @Autowired
    ProductDAOWrapper productDAOWrapper;

    /**
     * Tests renting a book.
     * @throws Exception if an error occurs during test execution
     */
   @Test
    public void testRentBooks() throws Exception {
        // Prepare a product bean for testing
        ProductBean productBean = new ProductBean();
        productBean.setProductName("XYZ");
        productBean.setCategoryName("Electronics");
        productBean.setPrice(30000.00);
        productBean.setQuantityInStock(20);
        
        Calendar calendar=Calendar.getInstance();
        calendar.set(2025, 1,22);
        
        Date expiryDate=calendar.getTime();
        SimpleDateFormat format=new SimpleDateFormat("dd-MMM-yyyy");
        String expiryDate1=format.format(expiryDate);
        expiryDate=format.parse(expiryDate1);
        productBean.setExpiryDate(expiryDate);
        
        Calendar calendar1=Calendar.getInstance();
        calendar1.set(2023, 1,22);
        Date manufactureDate=calendar1.getTime();
        SimpleDateFormat format2=new SimpleDateFormat("dd-MMM-yyyy");
        String manufactureDate1=format2.format(expiryDate);
        manufactureDate=format.parse(manufactureDate1);
        productBean.setManufactureDate(manufactureDate);
       
        // Add product and assert the result
        int productId = productDAOWrapper.addProduct(productBean);
        assertTrue(productId>0);
    }

    /**
     * Tests retrieving all Products by category.
     * @throws Exception if an error occurs during test execution
     */
   	@Test
    public void testShowAllProductsByCategory() throws Exception {
        // Prepare a product bean for testing
        ProductBean productBean = new ProductBean();
        productBean.setCategoryName("Oils & Ghee");

        // Retrieve rented books by email and assert the result
        List<ProductBean> productBeanList = productDAOWrapper.showAllProductsByCategory(productBean);
        assertTrue(productBeanList.size() > 0);
    }
   	
}
