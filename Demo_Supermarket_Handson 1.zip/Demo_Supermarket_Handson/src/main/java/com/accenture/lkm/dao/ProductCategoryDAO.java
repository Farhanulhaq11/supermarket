package com.accenture.lkm.dao;


import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.transaction.annotation.Transactional;
import com.accenture.lkm.entity.ProductCategoryEntity;
import java.util.List;

/**
 * The ProductCategoryDAO interface provides methods for performing CRUD operations on ProductCategoryEntity objects.
 * It uses Spring Data's RepositoryDefinition annotation to define the repository and specifies
 * the transaction management settings.
 */
@RepositoryDefinition(idClass = Integer.class, domainClass = ProductCategoryEntity.class)
@Transactional(value = "txManager")
public interface ProductCategoryDAO {

    /**
     * Retrieves all ProductCategoryEntity objects from the database.
     *
     * @return a list of all ProductCategoryEntity objects
     */
    List<ProductCategoryEntity> findAll();
}
