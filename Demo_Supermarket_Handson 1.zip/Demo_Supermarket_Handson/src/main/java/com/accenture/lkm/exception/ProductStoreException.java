package com.accenture.lkm.exception;

/**
 * RentNotAllowedException is a custom exception that is thrown when a user
 * attempts to rent more books than allowed. It extends the Exception class.
 */
public class ProductStoreException extends Exception {
    
    /**
     * Constructs a new RentNotAllowedException with the specified detail message.
     * @param message the detail message
     */
    public ProductStoreException(String message) {
        super(message);
    }
}
