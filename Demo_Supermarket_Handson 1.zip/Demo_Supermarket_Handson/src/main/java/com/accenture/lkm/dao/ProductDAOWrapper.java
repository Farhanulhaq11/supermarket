package com.accenture.lkm.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.lkm.businessbeans.ProductCategoryBean;
import com.accenture.lkm.businessbeans.DateRangeBean;
import com.accenture.lkm.businessbeans.ProductBean;

import com.accenture.lkm.entity.ProductCategoryEntity;
import com.accenture.lkm.entity.ProductEntity;
import com.accenture.lkm.exception.ProductStoreException;


/**
 * The ProductDAOWrapper class acts as a wrapper for the ProductDAO and ProductCategoryDAO interfaces,
 * providing methods to add product &  retrieve products details.
 * It uses Spring's transaction management and dependency injection features.
 */
@Repository
@Transactional(value = "txManager")
public class ProductDAOWrapper {

    @Autowired
    ProductDAO productDAO;

    @Autowired
    ProductCategoryDAO productCategoryDAO;

    /**
     * Add product to database
     *
     * @param productBean the details of the product
     * @return the product id of the new product
     * @throws ProductStoreException if the user has added more than 3 products of same category
     */
    public Integer addProduct(ProductBean productBean) throws ProductStoreException {
        ProductEntity productEntity;
        ProductEntity savedEntity;

        // Retrieve all rented books by the user's email
        List<ProductEntity> productEntityList = productDAO.findAllProductsByCategory(productBean.getCategoryName());

        // Check if the user has already rented 3 books
        if (productEntityList.size() == 3) {
            throw new ProductStoreException("Maximum 3 Products can be added for the " + productBean.getCategoryName());
        } else {
            // Convert the bean to entity and save it
            productEntity = convertBeanToEntity(productBean);
            savedEntity = productDAO.save(productEntity);
        }
        return savedEntity.getProductId();
    }

    /**
     * Retrieves all products between expiry dates.
     *
     * @param dateRangeBean the date range for the query
     * @return a list of ProductBean containing the details of all products between expiry dates
     * @throws Exception if any error occurs
     */
    public List<ProductBean> showAllProductsBetweenExpiryDates(DateRangeBean dateRangeBean) throws Exception {
        List<ProductBean> productBeanList = new ArrayList<>();
       
        // Retrieve all products between the specified expiry dates
        List<ProductEntity> productEntityList = productDAO.findAllProductsBetweenExpiryDates(dateRangeBean.getDateFrom(), dateRangeBean.getDateTo());
        productEntityList.forEach(productEntity -> {
            ProductBean productBean = convertEntityToBean(productEntity);
            productBeanList.add(productBean);
        });
       
        return productBeanList;
    }

    /**
     * Retrieves all products by category.
     *
     * @param productBean the product category detail
     * @return a list of ProductBean containing the details of all products of a particular category
     * @throws Exception if any error occurs
     */
    public List<ProductBean> showAllProductsByCategory(ProductBean productBean) throws Exception {
        List<ProductBean> productBeanList = new ArrayList<>();
        List<ProductEntity> productEntityList =productDAO.findAllProductsByCategory(productBean.getCategoryName());
       productEntityList.forEach(productEntity -> {
            ProductBean productBeans = convertEntityToBean(productEntity);
            productBeanList.add(productBeans);
        });
        return productBeanList;
    }

    /**
     * Get All  the product details sorted by Manufacture date.
     *
     * @param lowerBound for lower price range
     * @param upperBound for upper price range
     * @return the list of ProductBean objects
     * @throws Exception if any error occurs
     */
    public List<ProductBean> getAllProductsBetweenPriceAndSortedByManufactureDate(Double lowerBound,Double upperBound) throws Exception {
    	List<ProductBean> productBeanList=new ArrayList<>();
        List<ProductEntity> productEntityList=productDAO.findAllProductsBetweenPriceAndSortDescending(lowerBound, upperBound);
        productEntityList.forEach(productEntity->
        {
        	ProductBean productBean=convertEntityToBean(productEntity);
        	productBeanList.add(productBean);
        });
        return productBeanList;
    }
  
    /**
     * Retrieves all available product category.
     *
     * @return a list of all categories of products objects
     */
    public List<ProductCategoryBean> getAllProductCategory() throws Exception{
        List<ProductCategoryEntity> productCategoryEntityList = productCategoryDAO.findAll();
        List<ProductCategoryBean> productCategoryBeanList = new ArrayList<>();
        productCategoryEntityList.forEach(productCategoryEntity->{
            ProductCategoryBean productCategoryBean=convertEntityToBean(productCategoryEntity);
            productCategoryBeanList.add(productCategoryBean);
        });
        return productCategoryBeanList;
    }

    /**
     * Converts a ProductBean to a ProductEntity.
     *
     * @param productBean the product bean
     * @return the product entity
     */
    private ProductEntity convertBeanToEntity(ProductBean productBean) {
        ProductEntity productEntity = new ProductEntity();
        BeanUtils.copyProperties(productBean, productEntity);
        return productEntity;
    }

    /**
     * Converts a ProductEntity to a ProductBean.
     *
     * @param productEntity the product entity
     * @return the product bean
     */
    private ProductBean convertEntityToBean(ProductEntity productEntity) {
        ProductBean productBean = new ProductBean();
        BeanUtils.copyProperties(productEntity, productBean);
        return productBean;
    }
    /**
     * Converts a ProductCategoryEntity to a ProductCategoryBean.
     *
     * @param productCategoryEntity the product category entity
     * @return the product category bean
     */
    private ProductCategoryBean convertEntityToBean(ProductCategoryEntity productCategoryEntity) {
        ProductCategoryBean productCategoryBean = new ProductCategoryBean();
        BeanUtils.copyProperties(productCategoryEntity, productCategoryBean);
        return productCategoryBean;
    }
    
}
