package com.accenture.lkm.businessbeans;

import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * The DateRangeBean class represents a range of dates with a start date and an end date.
 * It includes attributes dateFrom and dateTo, along with their getter and setter methods.
 * The class also has constructors for creating instances with or without initial date values.
 */
public class DateRangeBean {
    
    // Start date of the date range; formatted as "dd-MMM-yyyy"
	@DateTimeFormat(pattern="dd-MMM-yyyy")
    private Date dateFrom;
    
    // End date of the date range; formatted as "dd-MMM-yyyy"
	@DateTimeFormat(pattern="dd-MMM-yyyy")
    private Date dateTo;
    
    // no-args constructor
    public DateRangeBean() {
    }
    
    // Constructor with dateFrom and dateTo parameters
    public DateRangeBean(Date dateFrom, Date dateTo) {
        super();
        this.dateFrom = dateFrom;
        this.dateTo = dateTo;
    }
    
    // Getter method for dateFrom
    public Date getDateFrom() {
        return dateFrom;
    }
    
    // Setter method for dateFrom
    public void setDateFrom(Date dateFrom) {
        this.dateFrom = dateFrom;
    }
    
    // Getter method for dateTo
    public Date getDateTo() {
        return dateTo;
    }
    
    // Setter method for dateTo
    public void setDateTo(Date dateTo) {
        this.dateTo = dateTo;
    }
}
