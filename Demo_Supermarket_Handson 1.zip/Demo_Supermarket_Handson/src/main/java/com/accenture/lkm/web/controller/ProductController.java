package com.accenture.lkm.web.controller;


import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.accenture.lkm.businessbeans.DateRangeBean;
import com.accenture.lkm.businessbeans.ProductBean;
import com.accenture.lkm.exception.ProductStoreException;
import com.accenture.lkm.service.ProductService;

//@SessionAttributes("productBean")
@Controller
public class ProductController {

    @Autowired
    ProductService productService;

    /**
     * Handles the request to load the Rent a Book page.
     * @return ModelAndView object with the RentABook view and a new BookRentBean.
     */
    @RequestMapping(value = "/loadAddProductPage.html")
    public ModelAndView loadAddProductPage() {
        return new ModelAndView("AddProductPage", "productBean", new ProductBean());
    }

    /**
     * Handles the request to save product details.
     * @param productBean the product  details submitted by the user.
     * @param result The binding result to hold validation errors.
     * @return ModelAndView object with the appropriate view and success message if no errors.
     * @throws ProductStoreException If the user tries to add more than 3 products of same category.
     */
    @RequestMapping(value = "/saveProductDetails.html", method = RequestMethod.POST)
    public ModelAndView saveProduct(@Valid @ModelAttribute("productBean") ProductBean productBean,
                                             BindingResult result) throws ProductStoreException {
        String viewName = null;
        Integer productId=null;
        
        ModelAndView modelAndView = new ModelAndView();
        if (result.hasErrors()) {
            viewName = "AddProductPage";
        } else {
           productId= productService.addProduct(productBean);
            viewName = "AddProductSuccess";
            modelAndView.addObject("message", "Product details added successfully : " + productId);
        }
        modelAndView.setViewName(viewName);
        return modelAndView;
    }

    /**
     * Handles the request to load the page for getting all product details within expiry date range.
     * @return ModelAndView object with the GetAllProductsBetweenExpiryDates view and a DateRangeBean object.
     */
    @RequestMapping(value = "/loadAllProductsBetweenDateRange.html")
    public ModelAndView loadGetAllProductsBetweenDatesPage() {
        return new ModelAndView("GetAllProductsBetweenExpiryDates", "dateRangeBean", new DateRangeBean());
    }

    /**
     * Handles the request to get all product details between the expiry date range.
     * @param dateRangeBean The date range submitted by the user.
     * @return ModelAndView object with the GetAllProductBetweenExpiryDates view and the list of ProductBean objects.
     * @throws Exception If there is an error.
     */
    @RequestMapping(value = "/GetAllProductsBetweenExpiryDateRange.html", method = RequestMethod.POST)
    public ModelAndView getAllProductsBetweenExpiryDates(@ModelAttribute("dateRangeBean") DateRangeBean dateRangeBean) throws Exception {
        List<ProductBean> productBeanList = productService.showAllProductsBetweenExpiryDates(dateRangeBean);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("GetAllProductsBetweenExpiryDates");
        modelAndView.addObject("productBeanList", productBeanList);
        return modelAndView;
    }

    /**
     * Handles the request to load the page for getting all product details by category
     * @return ModelAndView object with the GetAllProductsByCategory view 
     */
    @RequestMapping(value = "/loadAllProductsByCategory.html")
    public ModelAndView loadGetAllProductsCategoryPage() {
        return new ModelAndView("GetAllProductsCategory", "productBean", new ProductBean());
    }

    /**
     * Handles the request to get all product details of a specific category.
     * @param productBean The product bean submitted by the user.
     * @return ModelAndView object with the GetAllProductsCategory view and the list of products.
     * @throws Exception If there is an error during the operation.
     */
    @RequestMapping(value = "/GetAllProductsOfCategory.html", method = RequestMethod.POST)
    public ModelAndView getAllProductsByCategory(@ModelAttribute("productBean") ProductBean productBean) throws Exception {
        List<ProductBean> productBeanList = productService.showAllProductsByCategory(productBean);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("GetAllProductsCategory");
        modelAndView.addObject("productBeanList", productBeanList);
        return modelAndView;
    }
    
    /**
     * Handles the request to load the page for getting all product details between price range
     * @return ModelAndView object with the GetAllProductsPrice view 
     */
    @RequestMapping(value = "/loadAllProductsBetweenPrice.html")
    public ModelAndView loadGetAllProductsBetweenPricePage() {
        return new ModelAndView("GetAllProductsPriceRange", "productBean", new ProductBean());
    }

    /**
     * Handles the request to get all product details between price range and sorted by manufacture date
     * @param minPrice the minimum price range
     * @param maxPrice the maximum price range
     * @return ModelAndView object with the GetAllProductsPriceRange view and the list of products.
     * @throws Exception If there is an error during the operation.
     */
    @RequestMapping(value = "/GetAllProductsBetweenPriceRange.html", method = RequestMethod.POST)
    public ModelAndView getAllProductsBetweenPriceRange(@RequestParam("minPrice") Double minPrice, @RequestParam("maxPrice")Double maxPrice) throws Exception {
        List<ProductBean> productBeanList = productService.getAllProductsBetweenPriceAndSortedByManufactureDate(minPrice, maxPrice);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("GetAllProductsPriceRange");
        modelAndView.addObject("productBeanList", productBeanList);
        modelAndView.addObject("minValue", minPrice);
        modelAndView.addObject("maxValue", maxPrice);
        return modelAndView;
    }

    /**
     * Provides the list of all product categories as a model attribute for use in views.
     * @return list of product category name.
     * @throws Exception if error occurs
     *  
     */
    @ModelAttribute("category")
    public List<String> getAllProductCategory() throws Exception {
        return productService.getAllProductCategory();
    }

    /**
     * Handles ProductStoreException and returns a view with the error message.
     * @param exception The exception thrown when product is not saved.
     * @return ModelAndView object with the ProductStoreExceptionPage view and error message.
     */
    @ExceptionHandler(ProductStoreException.class)
    public ModelAndView handleRentNotAllowedException(ProductStoreException exception) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("ProductStoreExceptionPage");
        modelAndView.addObject("message", exception);
        return modelAndView;
    }

    /**
     * Handles any general exceptions and returns a view with the error message.
     * @param exception The general exception thrown.
     * @return ModelAndView object with the GeneralizedExceptionPage view and error message.
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView handleGeneralizedException(Exception exception) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("GeneralizedExceptionPage");
        modelAndView.addObject("message", exception);
        return modelAndView;
    }
}
