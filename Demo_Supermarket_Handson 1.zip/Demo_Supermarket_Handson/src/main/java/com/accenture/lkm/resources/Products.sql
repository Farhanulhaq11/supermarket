DROP DATABASE IF EXISTS supermarketdb;
CREATE DATABASE supermarketdb;
USE supermarketdb;

DROP TABLE IF EXISTS products;
CREATE TABLE `products` (
  `productId` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NULL,
  `category` varchar(50) NULL,
  `price` double DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `expiryDate` date DEFAULT NULL,
  `manufactureDate` date DEFAULT NULL,
  PRIMARY KEY (`productId`)
) ENGINE=InnoDB AUTO_INCREMENT=10001;


INSERT INTO products(productId, name, category,price,quantity,expiryDate, manufactureDate) 
values(10001,'Refined Sunflower Oil','Oils & Ghee',599.00,20,'2024-12-25','2021-01-01'),
	(10002,'Amul Pure Ghee','Oils & Ghee',640.00,10,'2025-12-01','2022-05-15'),
    (10003,'Aloo Bhujia','Namkeen & Mixtures',270.00,25,'2025-03-01','2024-09-05'),
    (10004,'Moong Dal','Namkeen & Mixtures',260.00,35,'2026-04-10','2024-05-15'),
    (10005,'Basmati Rice','Atta Rice & Dals',450.00,15,'2026-10-10','2024-10-05'),
    (10006,'Shudh Chakki Atta','Atta Rice & Dals',640.00,45,'2025-12-25','2024-05-01'),
    (10007,'Jeera Powder','Masalas & Dry Fruits',50.00,20,'2025-12-25','2024-05-01'),
    (10008,'Haldi Powder','Masalas & Dry Fruits',70.00,15,'2025-07-25','2023-07-09');
  commit;


DROP TABLE IF EXISTS productcategory;
CREATE TABLE `productcategory` (
  `categoryId` int NOT NULL AUTO_INCREMENT,
  `categoryName` varchar(50)  NULL,
  PRIMARY KEY (`categoryId`)
) ENGINE=InnoDB AUTO_INCREMENT=1001;

Insert into productcategory(categoryName) 
values('Oils & Ghee'),('Namekeens & Mixtures'),('Electronics'),('Cereals & Breakfast'),('Masalas & Dry Fruits'),('Atta Rice & Dals'),
('Biscuits & Cakes');
commit;

