package com.accenture.lkm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The ProductEntity class represents the "products" table in the database.
 * It contains details about the product such as product id, product name,price, quantity in stock, expiry date mobile number, book ID,
 * manufacture date
 */
/**
 * 
 */
@Entity
@Table(name = "products")
public class ProductEntity {
	
	//productId
	 @Id
	 @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer productId;
    
	 //productName
    @Column(name="name")
    private String productName;
    
    // price
    private Double price;
    
    //category
    @Column(name="category")
    private String categoryName;
    
    //quantityInStock
    @Column(name="quantity")
    private Integer quantityInStock;
    
    //expiryDate
    @Temporal(TemporalType.DATE)
    private Date expiryDate;
    
    //manufactureDate
    @Temporal(TemporalType.DATE)
    private Date manufactureDate;

    /**
     * Default constructor for ProductEntity.
     */
    public ProductEntity() {
        super();
    }
    
	/**
	 * @param productId
	 * @param productName
	 * @param price
	 * @param categoryName
	 * @param quantityInStock
	 * @param expiryDate
	 * @param manufactureDate
	 */
	public ProductEntity(Integer productId, String productName, double price,String categoryName, int quantityInStock, Date expiryDate,
			Date manufactureDate) {
		this.productId = productId;
		this.productName = productName;
		this.price = price;
		this.categoryName=categoryName;
		this.quantityInStock = quantityInStock;
		this.expiryDate = expiryDate;
		this.manufactureDate = manufactureDate;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	/**
	 * @return
	 */
	public Integer getProductId() {
		return productId;
	}

	/**
	 * @param productId
	 */
	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	/**
	 * @return
	 */
	public String getProductName() {
		return productName;
	}

	/**
	 * @param productName
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}

	/**
	 * @return
	 */
	public Double getPrice() {
		return price;
	}

	/**
	 * @param price
	 */
	public void setPrice(double price) {
		this.price = price;
	}

	/**
	 * @return
	 */
	public Integer getQuantityInStock() {
		return quantityInStock;
	}

	/**
	 * @param quantityInStock
	 */
	public void setQuantityInStock(int quantityInStock) {
		this.quantityInStock = quantityInStock;
	}

	/**
	 * @return
	 */
	public Date getExpiryDate() {
		return expiryDate;
	}

	/**
	 * @param expiryDate
	 */
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	/**
	 * @return
	 */
	public Date getManufactureDate() {
		return manufactureDate;
	}
	/**
	 * 
	 * @param manufactureDate
	 */
	public void setManufactureDate(Date manufactureDate) {
		this.manufactureDate = manufactureDate;
	}

   
   
}
